# Publico_Kommunikation
WPF-application for creating and managing quotes.

## Running Application with Database
___
### Step 1: Set Up the database
1. Open SSMS
2. Right-click on **Databases**
3. Click **Restore Database...**
4. Select **Device** and click **...**
5. Click **Add**
6. Select the file `Publico_Kommunikation_Full.bak`
7. Click **OK** three times
8. Verify installation by locating 'Publico_Kommunikation' under **Databases**

### Step 2: Add User Access
1. Open SSMS
2. Expand **Security** under the `Publico_Kommunikation` database
3. Right-click on **Users**
4. Click **New User...**
5. Enter a **User name**
6. Click *...* under **Login Name**
7. Click **Browse...**
8. Choose the user
9. Click **OK** three times
10. Verify the user addition by locating the username under **Users**

### Step 3: Integrate the database with the application
1. Open `Publico_Kommunikation.sln`
2. In `appsettings.json`, add personal connection string
3. On **line 59** in `App.xaml.cs`, insert the name of your connection string as the parameter

### Step 4: Run the application
1. Open `Publico_Kommunikation.sln`
2. Build and run the application
