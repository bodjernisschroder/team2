﻿using System.Windows.Controls;

namespace Publico_Kommunikation.MVVM.Views
{
    /// <summary>
    /// Interaction logic for QuotesView.xaml
    /// </summary>
    public partial class QuotesView : UserControl
    {
        public QuotesView()
        {
            InitializeComponent();
        }
    }
}
