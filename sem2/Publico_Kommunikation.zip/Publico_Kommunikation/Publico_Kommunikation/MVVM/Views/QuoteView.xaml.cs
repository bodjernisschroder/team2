﻿using System.Windows.Controls;

namespace Publico_Kommunikation.MVVM.Views
{
    /// <summary>
    /// Interaction logic for QuoteView.xaml
    /// </summary>
    public partial class QuoteView : UserControl
    {
        public QuoteView()
        {
            InitializeComponent();
        }
    }
}
