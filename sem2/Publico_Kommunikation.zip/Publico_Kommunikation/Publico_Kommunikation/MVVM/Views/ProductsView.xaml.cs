﻿using System.Windows.Controls;

namespace Publico_Kommunikation.MVVM.Views
{
    /// <summary>
    /// Interaction logic for ProductsView.xaml
    /// </summary>
    public partial class ProductsView : UserControl
    {
        public ProductsView()
        {
            InitializeComponent();
        }
    }
}
